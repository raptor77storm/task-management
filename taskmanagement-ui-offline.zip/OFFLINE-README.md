# Task Management UI - Offline Version

A fully **offline desktop application** for managing projects, tasks with subtasks, and team members. **No internet connection or backend server required!**

## ✅ Features

- 📋 **Projects** - Create and organize projects
- ✅ **Tasks & Subtasks** - Create tasks with expandable subtasks (hierarchical structure)
- 👥 **Team Members** - Manage team members with roles and color coding
- 🔗 **Task Assignment** - Assign tasks to team members
- 📊 **Dashboard** - Real-time statistics and team workload overview
- 💾 **Offline Storage** - All data stored locally (browser storage)
- 🚀 **Zero Setup** - Works completely offline
- 📱 **Responsive UI**

## 🚀 Quick Start

### Windows Users
Double-click: **`start-app.bat`**

### Mac/Linux Users
Run in terminal:
```bash
./start-app.sh
```

The app will automatically:
1. Install required packages (first run only)
2. Start a local server
3. Open your browser to `http://localhost:3000`
4. Load with sample data included

## 📊 Sample Data

The app comes pre-loaded with:

**4 Team Members:**
- Alice Johnson (Project Manager) 
- Bob Smith (Developer)
- Carol White (Designer)
- David Brown (QA Engineer)

**3 Sample Projects:**
- Website Redesign
- Mobile App
- API Optimization

**Sample Tasks with Subtasks:**
- Design Mockups (with Homepage & Product page subtasks)
- Frontend Development (with Setup routing subtask)
- Setup React Native
- Index Database

Feel free to modify, delete, or add new data!

## 🎯 How to Use

### Dashboard
- View overall statistics (projects, tasks, workload)
- See team member workload and progress
- Track task status and priorities

### Team Members
- Add new team members with role and email
- Each member gets a unique color for easy identification
- Remove members as needed

### Projects
- Create new projects
- Assign tasks to projects
- Delete projects (also removes associated tasks)

### Tasks
- Create tasks in any project
- Add subtasks by clicking the **+** button
- Assign tasks to team members via dropdown
- Change task status (Not Started → In Progress → Completed)
- Change priority (Low/Medium/High)
- Delete tasks (also removes subtasks)
- Expand/collapse tasks to view subtasks (▶ / ▼)

## 💾 Data Storage

All your data is saved automatically in browser storage:
- **No server needed** — Works completely offline
- **Data persists** between sessions
- **Private** — Data never leaves your computer
- **Fast** — All data accessed locally

## 🆘 Troubleshooting

**If the app doesn't start:**
1. Make sure Node.js 16+ is installed: https://nodejs.org/
2. Run the batch file/shell script as Administrator
3. Check that port 3000 is not in use

**If you see "command not found" error:**
- Node.js may not be installed or not in PATH
- Restart your computer and try again
- Or run `npx serve -s build -l 3000` manually in the project folder

**If data looks different after restart:**
- Clear browser cache (Ctrl+Shift+Delete) and refresh

**To reset to sample data:**
- Open browser DevTools (F12)
- Go to Console tab
- Paste: `localStorage.clear(); location.reload();`

## 📝 Requirements

- **Node.js 16+** (download from https://nodejs.org/)
- Any modern browser (Chrome, Firefox, Safari, Edge recommended)
- ~600MB disk space

## 🔧 Advanced: Running Without Launcher

If you prefer manual control:

```bash
# Install dependencies (one-time only)
npm install

# Start the app
npx serve -s build -l 3000

# Then open: http://localhost:3000
```

## 📦 Sharing Your Data

To backup or share your data:
1. Open browser DevTools (F12)
2. Go to Console
3. Copy projects: `copy(localStorage.getItem('taskmanagement_projects'))`
4. Copy tasks: `copy(localStorage.getItem('taskmanagement_tasks'))`
5. Copy team members: `copy(localStorage.getItem('taskmanagement_team_members'))`
6. Save the copied JSON text for backup

To restore:
1. Open DevTools → Console
2. Paste: `localStorage.setItem('taskmanagement_projects', '[your-json-here]')`
3. Refresh the page

## ⚙️ System Requirements

- **CPU:** Any modern processor
- **RAM:** 512MB minimum
- **OS:** Windows 7+, Mac OS X 10+, Linux
- **Disk:** 600MB free space

## 🎓 Tips

- Use the Dashboard to monitor team progress
- Color-coded team members make assignments easy to see
- Subtasks help break down complex tasks
- Change task status as work progresses
- Assign high-priority tasks strategically

---

**Enjoy!** 🎉 This app is fully functional offline with zero backend required. Perfect for teams that need simple, reliable task management without cloud dependencies.

